from langgraph_sdk import get_sync_client

client = get_sync_client(url="http://127.0.0.1:2024")
run_context = {"user_id": "debug-user-001"}

thread = client.threads.create()
tid = thread["thread_id"]
print(f"thread_id={tid}")

def print_stream(label: str, **kwargs) -> None:
    print(f"\n=== {label} ===")
    for chunk in client.runs.stream(
        tid,
        assistant_id="agent",
        context=run_context,
        **kwargs,
    ):
        print(chunk.event, ":", getattr(chunk, "data", None))

try:
    print_stream(
        "first run",
        input={"messages": [{"role": "user", "content": "帮我推荐西安市临潼区的房子"}]},
    )

    state = client.threads.get_state(tid)
    print("\n=== state after first run ===")
    print(state)

    print_stream("resume", command={"resume": "预算 2000 到 3000"})

    state = client.threads.get_state(tid)
    print("\n=== state after resume ===")
    print(state)
except Exception as exc:
    print("\n=== script error ===")
    print(type(exc).__name__, exc)

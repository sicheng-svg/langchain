# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A LangGraph-based house rental agent (房源推荐/预定系统) that helps users find and reserve rental housing in Chinese cities. Uses DeepSeek as the LLM provider and MySQL as the property database.

## Commands

- **Run dev server:** `langgraph dev`
- **Run unit tests:** `make test` or `python -m pytest tests/unit_tests/`
- **Run single test:** `python -m pytest tests/unit_tests/test_configuration.py`
- **Run integration tests:** `make integration_tests`
- **Lint:** `make lint`
- **Format:** `make format`
- **Install:** `pip install -e . "langgraph-cli[inmem]"` (or use `uv`)

## Architecture

The system is a multi-graph LangGraph application with one main graph and three subgraphs, defined in `langgraph.json`.

### Main Graph (`src/agent/graph.py`)

Entry point. Flow: `get_store_info` → `identify_question` → router. The router classifies user intent into four categories:
- **recommend_house** → `recommendGraph` → `need_reserve` (interrupt) → optionally `reserveGraph`
- **reserve_house** → `reserveGraph`
- **get_info** → `get_user_preferences`
- **others** → `extendGraph`

### Subgraphs (`src/agent/`)

- **`recommend.py`** — Collects user rental preferences (city, budget, district, room type, etc.), queries MySQL via `SQLDatabaseToolkit`, generates and validates SQL, returns matching properties. Uses `interrupt()` to gather missing required fields (city, budget).
- **`reserve.py`** — Sequential interrupt-driven flow to collect title, phone, ID card, then generates an order via tool call. Uses `checkpointer=True` for stateful multi-turn.
- **`extend.py`** — Simple fallback for general conversation.

### Code Organization

- **`src/state/`** — State schemas (TypedDict/MessagesState subclasses) for each graph
- **`src/node/`** — Node implementations (LLM calls, DB queries, interrupt logic)
- **`src/common/`** — Shared: `llm.py` (DeepSeek model), `context.py` (user_id context schema), `store.py` (Pydantic models for user preferences and reservation info)

### Key Patterns

- **User preferences** are persisted via LangGraph `BaseStore` with namespace `(user_id, "preference")`. Budget ranges are tracked and widened over time.
- **`interrupt()`** is used extensively for multi-turn user input (missing info collection, reservation confirmation, field-by-field data entry).
- **Structured output** via `model.with_structured_output(schema, method="function_calling")` for intent classification and info extraction.
- **All prompts and UI text are in Chinese.**

## Environment

Requires a `.env` file with MySQL credentials (`DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, `DB_NAME`) and optionally `LANGSMITH_API_KEY`. The DeepSeek API key must also be configured.

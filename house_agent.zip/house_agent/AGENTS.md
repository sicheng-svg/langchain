# Repository Guidelines

## Project Structure & Module Organization

Core application code lives under `src/`. `src/agent/` defines the main LangGraph flow and subgraphs, `src/node/` contains node implementations, `src/state/` holds state schemas, and `src/common/` contains shared context, storage, and LLM helpers. Tests are split into `tests/unit_tests/` and `tests/integration_tests/`. Repository-level helpers include `langgraph.json` for graph configuration, `house_sql.sql` for database setup, and `static/` for documentation assets.

## Build, Test, and Development Commands

- `pip install -e . "langgraph-cli[inmem]"` installs the package and local LangGraph tooling.
- `langgraph dev` starts the local LangGraph server for interactive development.
- `make test` runs unit tests in `tests/unit_tests/`.
- `make integration_tests` runs integration coverage for graph behavior.
- `make lint` runs `ruff` checks, import-order validation, and `mypy --strict`.
- `make format` applies `ruff format` and fixes import ordering.

Use `python -m pytest tests/unit_tests/test_configuration.py` to run a single test file.

## Coding Style & Naming Conventions

Follow Python 3.10+ conventions with 4-space indentation. Keep modules and functions in `snake_case`; use descriptive graph/node names that match the workflow, such as `recommendGraph`, `reserveGraph`, and `get_user_preferences`. Type hints are expected, and `mypy --strict` should pass before review. `ruff` enforces linting, import sorting, and Google-style docstring rules; keep comments brief and only where logic is not obvious.

## Testing Guidelines

Use `pytest` for all tests. Place fast, isolated checks in `tests/unit_tests/` and graph or async flow tests in `tests/integration_tests/`. Name files `test_*.py` and test functions `test_*`. Add or update tests with every behavior change, especially around routing, interrupts, and persistence-backed preference handling.

## Commit & Pull Request Guidelines

Git history is not available in this workspace, so use short imperative commit messages such as `Add reservation state validation` or `Fix recommend graph routing`. Keep commits focused. Pull requests should include a concise summary, note any schema or environment changes, link the relevant issue, and attach screenshots only when UI or Studio behavior changes.

## Security & Configuration Tips

Store secrets in `.env`, not in source. Expected settings include `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, `DB_NAME`, API credentials for the configured LLM provider, and optional `LANGSMITH_API_KEY`. Avoid hardcoding database or model settings in graph code.

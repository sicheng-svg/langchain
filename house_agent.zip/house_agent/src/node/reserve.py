import uuid
from typing import Annotated, Any

from src.common.store import reserve_info, userPreference
from src.state.reserve import reserveState
from src.common.llm import model
from src.common.context import context_schema

from langchain_core.messages import HumanMessage, SystemMessage
from langchain.tools import tool
from langgraph.prebuilt import InjectedStore
from langgraph.types import interrupt
from langgraph.prebuilt import ToolNode, ToolRuntime, InjectedStore

def get_title(state: reserveState):
    prompt = "请输入要预定的房源名称"
    while True:
        title = interrupt(prompt)
        if title:
            return {"title": title}
        prompt = f"{title} 无效，请输入正确的房源名称"

def get_phone(state: reserveState):
    prompt = "请输入手机号"
    while True:
        phone = interrupt(prompt)
        if phone: # 简单判断
            return {"phone": phone}
        prompt = f"{phone} 无效，请输入正确的手机号"

def get_id(state: reserveState):
    prompt = "请输入身份证号"
    while True:
        id = interrupt(prompt)
        if id:
            return {"id": id}
        prompt = f"{id} 无效，请输入正确的身份证号"
    
# 将输入的信息包装成一个HumanMessage
def add_reserve_message(state: reserveState):
    reserve_prompt = """根据提供的信息，帮我预定房源。
    - 预定的房源标题: {title}
    - 用户预定号码: {phone_number}
    - 用户身份证号码: {id_card}"""
    reserve_message = HumanMessage(content=reserve_prompt.format(
        title=state['title'],
        phone_number=state['phone'],
        id_card=state['id']
    ))
    return {"messages": [reserve_message]}

@tool
def generate_order(title: str, phone: str, runtime: ToolRuntime[context_schema], store: Annotated[Any, InjectedStore()]):
    """模拟预定房子，直接生成工单号"""
    # 1.生成工单号
    order = str(uuid.uuid4())

    # 2. 构建预定信息
    reserved_house = reserve_info(
        order_id=order,
        title=title,
        phone_number=phone,
    )

    # 3.持久化用户个性化数据
    user_id = runtime.context.user_id
    namespace = (user_id, "preference")
    pref_result = store.search(namespace)
    if len(pref_result) == 0:
        # 新增
        prefs = userPreference(reserved_lists=[reserved_house])
        store.put(namespace, str(uuid.uuid4()), prefs.model_dump(exclude_none=True))
    else:
        # 有值，更新​
        prefs = pref_result[0].value or {}
        prefs.setdefault('reserved_lists', []).append(reserved_house)
        store.put(
            namespace,
            pref_result[0].key,
            prefs
        )
    
    return f"已成功预定房源：{title}，预定工单号为：{order}"


# 用来调用工具生成工单号或者直接返回最终结果
def call_orders(state: reserveState):
    return {"messages": [model.bind_tools([generate_order]).invoke(
        [
            SystemMessage(content="你是一个工单生成的助手，支持调用工具进行房源预定工单生成。支持查看查询的结果并返回最终答案.必须遵守的规则：如果需要调用工具，则直接生成工单，不需要对输入的信息进行判断")
        ] 
            + state["messages"]
    )]}
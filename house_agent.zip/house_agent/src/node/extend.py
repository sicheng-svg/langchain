from langgraph.graph import MessagesState
from langchain_core.messages import SystemMessage
from src.common.llm import model

def extend(state: MessagesState):
    return {
        "messages": [model.invoke([SystemMessage(content="你是一个善于助人的ai助手, 会根据用户提出的问题以及历史对话进行回答")] + state["messages"])]
    }
from src.common.context import context_schema
from src.state.main import State, need_reserve_output
from src.common.llm import model

from typing_extensions import Literal
from pydantic import BaseModel, Field

from langgraph.runtime import Runtime
from langgraph.store.base import BaseStore
from langgraph.types import interrupt
from langchain_core.messages import SystemMessage, HumanMessage, filter_messages

# 获取用户偏好数据，辅助后续节点
def get_store_info(state: State, runtime: Runtime[context_schema], *, store: BaseStore):
    # 获取偏好数据前，需要先获取上下文，构建namespace
    user_id = runtime.context.user_id
    namespace = (user_id, "preference")
    prefs = store.search(namespace)
    if prefs and prefs[0]:
        return {"user_preference": prefs[0].value}
    return {"user_preference": {}}

# 智能路由，确定走向
class UserMessage(BaseModel):
    """用户提问的消息摘要"""
    type: Literal["recommend_house", "reserve_house", "get_info", "others"] = Field(description="根据用户问题描述判断问题类型：推荐房源、预定房源、获取信息、其他内容")

def identify_question(state: State):
    system_message = SystemMessage(content="""
        你是一个根据描述提取信息提取专家。请从用户的描述中提取用户想要咨询的相关信息。
        严谨根据语义推断信息，但不能猜测或编造信息。"""
    )
    lastMsg = state["messages"][-1]
    intent = model.with_structured_output(UserMessage, method="function_calling").invoke([system_message, lastMsg])
    return {
        "user_intent": intent.type
    }

# 推荐完房子后执行该节点，利用中断获取用户输入，判断是否需要预定
def need_reserve(state: State) -> need_reserve_output:
    prompt = f"已经为您推荐合适的房源，是否需要帮您预订房源？\n"
    prompt += "如果不需要，请输入'**不需要**'。\n"
    prompt += "如果需要，请输入'**需要**'。\n(注意输入其它值无效)"
    # 中断，等待用户输入​
    answer = interrupt(prompt)
    return {"reserve": str(answer).strip()}

# 返回用户偏好信息
def get_user_preferences(state: State):
    prefs = state.get("user_preference", {})
    user_messages = filter_messages(state["messages"], include_types="human")

    # 格式化已经预定过的信息
    reserved_list = prefs.get('reserved_lists', [])
    if reserved_list:
        reserved_str = "\n"
        for i, item in enumerate(reserved_list, 1):
            reserved_str += f"{i}. 预定工单ID: {item.order_id}, " \
            f"房源标题: {item.title}, " \
            f"预定电话: {item.phone_number}\n"
    else:
        reserved_str = "无"

    response = model.invoke([SystemMessage(content="""你是一个乐于助人的助手，可以根据用户偏好信息进行回
        复。
        如果有的偏好数据为空，不要猜测或编造数据。
        不要直接回复偏好数据是什么，要结合问题进行生动回复。
        如果问题与用户偏好数据无关，直接回复即可。"""),
        HumanMessage(content="用户的历史偏好信息如下："
            f"1. 最低预算：{prefs.get('budget_min')}"
            f"2. 最高预算：{prefs.get('budget_max')}"
            f"3. 已预定过的信息：{reserved_str}"
        ),
        user_messages[-1]
        ])
    return {"messages": [response]}
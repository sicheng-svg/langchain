"""
    推荐子图，根据用户的输入以及用户的偏好，为用户提供推荐房源
"""
import os
import uuid
from typing import Optional
from pydantic import Field, BaseModel
from dotenv import load_dotenv

from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_core.messages import filter_messages, HumanMessage, SystemMessage, AIMessage
from langgraph.runtime import Runtime
from langgraph.store.base import BaseStore
from langgraph.types import interrupt
from langgraph.prebuilt import ToolNode

from src.common.context import context_schema
from src.common.llm import model
from src.common.store import userPreference
from src.state.recommend import recommendState, get_recommend_info


class UserInfo(BaseModel):
    """用户的租房需求信息"""

    city: Optional[str] = Field(
        default=None,
        description="用户所在或想要租房的城市，例如：西安、北京、上海"
    )
    district: Optional[str] = Field(
        default=None,
        description="用户想要租房的具体区域或行政区，例如：雁塔区、碑林区、海淀区"
    )
    budget_min: Optional[float] = Field(
        default=None,
        description="用户的最低预算，单位为元/月。如果是xx元以内，要设置最小值为0"
    )
    budget_max: Optional[float] = Field(
        default=None,
        description="用户的最高预算，单位为元/月。如果是xx元以上，最大值设置为10000"
    )
    room_type: Optional[str] = Field(
        default=None,
        description="房屋类型，例如：整租、合租、公寓、一室一厅、两室一厅"
    )
    orientation: Optional[str] = Field(
        default=None,
        description="房屋朝向，例如：朝南、朝北、东南、南北通透"
    )
    room_count: Optional[int] = Field(
        default=None,
        description="需要推荐的房屋数量"
    )
    others: Optional[str] = Field(
        default=None,
        description="特殊要求，例如：带阳台、独立卫生间、近地铁、可养宠物、有电梯等"
    )

# 节点：获取用户信息
def collect_user_info(state: recommendState, runtime: Runtime[context_schema], *, store: BaseStore):
    """收集用户的推荐信息"""

    # 1.获取用户输入 以及 用户的历史偏好数据(存储在store中)
    user_messages = filter_messages(state["messages"], include_types="human")
    user_preference = state.get("user_preference")
    if user_preference and (user_preference["budget_min"] or user_preference["budget_max"]):
        extract_message = [HumanMessage(content="用户的历史偏好数据如下"
                                        f"1.最低预算：{user_preference['budget_min']}"
                                        f"2.最高预算：{user_preference['budget_max']}"),
                            user_messages[-1]]
    else:# 无偏好数据
        extract_message = [user_messages[-1]]

    # 2.利用llm，根据用户的输入以及偏好数据，将输入转化为结构化的数据
    def extract_info(messages) -> UserInfo:
        system_message = SystemMessage(
            content="""
                你是一个租房需求信息提取专家。请从用户的描述与历史信息中提取租房相关信息。
                如果用户历史偏好信息与最新用户消息冲突，以最新的用户消息为主。
                只提取用户明确提到的信息，不要猜测或推断。
                如果某个信息用户没有提到，就返回null。
                例如，1000-2000，表示最低预算为1000，最高预算为2000
                注意预算的单位可能是元/月、元/天等，请统一转换为元/月。
                如果用户提到价格范围，请分别提取最低和最高预算。
                如果用户提到推荐几套房，提取room_count字段。
            """
        )
        return model.with_structured_output(schema=UserInfo, method="function_calling").invoke([system_message] + messages)

    def update_state(current_state: dict, info: UserInfo) -> dict:
        if not info:
            return current_state
        user_info_dict = info.model_dump(exclude_none=True)
        current_state.update(user_info_dict)
        return current_state

    updated_state = {}  # 最终提出的所有信息以及偏好都在这里存储，因为流程可能被打断，有多次输入，用这个来接受每一次更新的值
    extracted_info = extract_info(extract_message) # 根据第一步获取的历史偏好以及用户输入，利用llm进行结构化的输出，本质上就是提取关键信息为dict
    updated_state = update_state(updated_state, extracted_info)


    # 3.如果结构化中的数据，有些关键字段没有填入，比如city、budget。此时需要使用中断，让用户输入
    missingInfo = []
    if not updated_state.get("city"): # 如果最终的输入中没有city，则标记
        missingInfo.append("**城市")
    if not updated_state.get("budget_min") or not updated_state.get("budget_max"):
        missingInfo.append("**预算区间**")
    
    if missingInfo: # 如果misssingInfo不为空，说明有关键信息未给出，此时需要中断
        prompt = f"为了给您推荐合适的房源，请提供以下信息:{'，'.join(missingInfo)}和其它信息。\n"
        prompt += "如果您不想提供，请输入'**不提供**',我会根据已有信息为您推荐房源。"
        input = interrupt(prompt)
        if str(input).strip() == "不提供":
            # 确认缺失关键字段，用户还不提供。则给这些字段随机值
            if not updated_state.get("city"):
                updated_state["city"] = "随机城市"
            if not updated_state.get("budget_min"):
                updated_state["budget_min"] = 500.0
            if not updated_state.get("budget_max"):
                updated_state["budget_max"] = 5000.0
            if not updated_state.get("room_count"):
                updated_state["room_count"] = 5
        else:
            # 用户提供了字段，但提供的可能是一段话，也可能是几个字
            # 将其构造为一个humanmessage，调用上面的提取信息的函数，重新进行提取
            user_response_msg = HumanMessage(content=str(input))
            extracted_info = extract_info([user_response_msg])
            updated_state = update_state(updated_state, extracted_info)

    # 4.持久化处理，将用户的偏好信息进行更新或者是新增
    if updated_state.get("budget_min") or updated_state.get("budget_max"):
        # 有可能会更新，如果输入的区间在已有的区间内，则不更新
        user_id = runtime.context.user_id
        namespace = (user_id, "preference")
        prefs_result = store.search(namespace)
        if len(prefs_result) == 0:
            # 原本没有偏好，本次是新增
            prefs = userPreference(
                budget_min=updated_state.get("budget_min"),
                budget_max=updated_state.get("budget_max"),
            )
            store.put(namespace,
                      str(uuid.uuid4()),
                      prefs.model_dump(exclude_none=True))
            updated_state["user_preference"] = prefs.model_dump(exclude_none=True)
        else:
            # 如果原本有，则判断是否需要更新
            prefs = prefs_result[0].value
            store_min = prefs["budget_min"]
            store_max = prefs["budget_max"]
            cur_min = updated_state.get("budget_min")
            cur_max = updated_state.get("budget_max")
            update_min = False   # 是否更新最小预算
            update_max = False   # 是否更新最大预算 
            if store_min is not None and cur_min is not None and cur_min < store_min:
                # 都不为空，就比较
                update_min = True
            elif store_min is None and cur_min is not None:
                # store 没有，但 cur 有
                update_min = True

            if store_max is not None and cur_max is not None and cur_max > store_max:
                update_max = True
            elif store_max is None and cur_max is not None:
                update_max = True

            if update_min or update_max:
                if update_min:
                    prefs["budget_min"] = cur_min
                if update_max:
                    prefs["budget_max"] = cur_max
                # 更新操作
                store.put(
                    namespace,
                    prefs_result[0].key, # 根据查询到的key进行更新
                    prefs
                )
                updated_state["user_preference"] = prefs

    # 5.返回最终结果
    updated_state["messages"] = [HumanMessage(content=get_recommend_info(updated_state))]

    print(f"已收集用户信息：\n城市：{updated_state.get('city')}"
          f"区域：{updated_state.get('district')}"
          f"预算：{updated_state.get('budget_min')}-{updated_state.get('budget_max')}元/月"
          f"房间数：{updated_state.get('room_count')}")

    # 返回：覆盖了推荐参数和偏好数据，更新了消息列表
    return updated_state


# 通过环境变量连接数据库
load_dotenv()
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')
db_host = os.getenv('DB_HOST')
db_port = os.getenv('DB_PORT')
db_name = os.getenv('DB_NAME')
db = SQLDatabase.from_uri(f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}")

# 获取数据库工具​
# sql_db_query
# sql_db_schema
# sql_db_list_tables
# sql_db_query_checker
toolkit = SQLDatabaseToolkit(db=db, llm=model)
tools = toolkit.get_tools()

# 节点：获取表结构
get_schema_tool =  next(tool for tool in tools if tool.name == "sql_db_schema")
get_schema_node = ToolNode([get_schema_tool], name="get_schema")  # 工具执行节点（返回ToolMessage）

# 节点：执行sql查询
run_query_tool =  next(tool for tool in tools if tool.name == "sql_db_query")
run_query_node = ToolNode([run_query_tool], name="run_query")     # 工具执行节点（返回ToolMessage）

# 节点：获取数据库中的所有表
def list_tables(state: recommendState):
    # 1. 获取AIMessage(tool_calls)
    tool_call = {
        "name": "sql_db_list_tables",
        "args": {},
        "id": "123123",
        "type": "tool_call",
    }
    # 模拟必定调用工具
    tool_call_message = AIMessage(content="", tool_calls=[tool_call])

    # 2. 手动调用工具：sql_db_list_tables
    list_tables_tool = next(tool for tool in tools if tool.name == "sql_db_list_tables")
    tool_message = list_tables_tool.invoke(tool_call)

    # 3. 整合结果
    response = AIMessage(content=f"可用的表：{tool_message.content}")
    return {
        "messages": [tool_call_message, tool_message, response]
    }

# 节点：绑定工具（获取表信息），让LLM将来必定执行工具节点
def call_get_schema(state: recommendState):
    llm_with_tools =  model.bind_tools([get_schema_tool], tool_choice="any")
    # llm 根据历史消息筛选表，并获取需要的表信息
    response =  llm_with_tools.invoke(state["messages"])  # AIMessage(tool_calls)
    # 下一步一定是会调用get_schema_tool工具的！
    return {
        "messages": [response]
    }

# 生成sql或者直接总结结果的节点
def generate_query(state: recommendState):
    generate_query_system_prompt = """
            您是一个设计用于与SQL数据库交互的代理。
            给定一个输入问题，创建一个语法正确的{dialect}查询来运行，然后查看查询的结果并返回答案。
            需要根据rows from table的示例设置真实查询的值。
            除非用户指定了他们希望获得的特定数量的示例，否则始终将查询限制为最多{top_k}个结果。
            您可以按相关列对结果排序，以返回最感兴趣的结果。不要查询特定表中的所有列，只查询给定问题的相关列。
            不要修改任何从数据库中返回来的数据，包括titile、price等信息
            不要对数据库做任何DML语句（INSERT， UPDATE， DELETE， DROP等)。
        """
    system_prompt = generate_query_system_prompt.format(dialect=db.dialect, top_k=state.get("room_count", 5))
    system_message = SystemMessage(content=system_prompt)
    llm_with_tools = model.bind_tools([run_query_tool])
    return {
        "messages":[llm_with_tools.invoke([system_message] + state["messages"])]
    }

# 检查sql节点，在产生sql之后执行，如果产生的sql带了tool_calls，则必须走到check
# check后必须调用工具，执行sql
def check_query(state: recommendState):
    check_query_system_prompt = """
        你是一个非常注重细节的SQL专家。仔细检查{dialect}查询中的常见错误，包括：
        -使用NULL值的NOT IN
        -在应该使用UNION ALL时使用UNION
        -使用BETWEEN表示独占范围
        -谓词中的数据类型不匹配
        -正确引用标识符
        -使用正确数量的函数参数
        -转换为正确的数据类型
        -使用合适的列进行连接
        如果存在上述任何错误，请重写查询。如果没有错误，只需复制原始查询即可。
        在运行此检查之后，您将调用适当的工具来执行查询。
        """.format(dialect=db.dialect)
    system_message = SystemMessage(content=check_query_system_prompt)
    tool_call = state["messages"][-1].tool_calls[0]
    query = tool_call["args"].get("query", str(tool_call["args"]))
    user_message = HumanMessage(content=query)
    llm_with_tools = model.bind_tools([run_query_tool], tool_choice="any")
    response = llm_with_tools.invoke([system_message, user_message])

    # 合并，将最新的AIMessage的id改为前一个的id
    response.id = state["messages"][-1].id
    return {
        "messages": [response]
    }

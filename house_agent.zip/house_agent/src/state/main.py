from typing import Optional, TypedDict

from langgraph.graph import MessagesState

class State(MessagesState):
    user_preference: dict # 用户偏好信息
    user_intent: str      # 用户意图，用来让大模型智能路由

    # 推荐子图与主图共享的字段。否则子图作为主图节点被 interrupt/resume 时，
    # 非共享字段可能无法稳定地跨图恢复。
    # city: Optional[str]
    # budget_min: Optional[float]
    # budget_max: Optional[float]
    # district: Optional[str]
    # room_type: Optional[str]
    # orientation: Optional[str]
    # room_count: Optional[int]
    # others: Optional[str]
    # missing_fields: Optional[list[str]]

    # # 预定子图与主图共享的字段
    # title: Optional[str]
    # phone: Optional[str]
    # id: Optional[str]

# 推荐子图执行完后，会打印提示消息，让用户决定是否要进行预定
class need_reserve_output(TypedDict):
    reserve: str

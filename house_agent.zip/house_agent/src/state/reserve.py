from langgraph.graph import MessagesState

class reserveState(MessagesState):
    title: str
    phone: str
    id: str
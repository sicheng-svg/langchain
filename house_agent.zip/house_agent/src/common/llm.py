from langchain.chat_models import init_chat_model

model = init_chat_model(
    model="deepseek-chat", 
    model_provider="openai", 
    base_url="https://api.deepseek.com/v1", 
    temperature=0
)
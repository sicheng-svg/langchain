from dataclasses import dataclass

@dataclass
class context_schema:
    user_id: str
from typing_extensions import Literal
from langgraph.graph import StateGraph
from langgraph.constants import START, END

from src.state.main import State, need_reserve_output
from src.common.context import context_schema
from src.node.main import get_store_info, identify_question, need_reserve, get_user_preferences
from src.agent.extend import extendGraph
from src.agent.recommend import recommendGraph
from src.agent.reserve import reserveGraph


def router(state: State) -> Literal["recommended_graph","reserve_graph", "extend_graph", "get_user_preferences"]:
    intent = state["user_intent"]
    if intent == "recommend_house":
        return "recommendGraph"
    elif intent == "reserve_house":
        return "reserveGraph"
    elif intent == "get_info":
        return "get_user_preferences"
    elif intent == "others":
        return "extendGraph"
    
def reserve_or_not(reserve: need_reserve_output):
    if reserve["reserve"] == "需要":
        return "reserveGraph"
    return END

# Define the graph
graph = (
    StateGraph(State, context_schema=context_schema)
    .add_node(get_store_info)
    .add_node(identify_question)
    .add_node("recommendGraph", recommendGraph)
    .add_node("reserveGraph", reserveGraph)
    .add_node("extendGraph", extendGraph)
    .add_node(need_reserve)
    .add_node(get_user_preferences)
    .add_edge(START, "get_store_info")
    .add_edge("get_store_info", "identify_question")
    .add_conditional_edges(
        "identify_question",
        router,
        ["recommendGraph", "reserveGraph", "extendGraph", "get_user_preferences"],
    )
    .add_edge("recommendGraph", "need_reserve")
    .add_conditional_edges(
        "need_reserve", 
        reserve_or_not, 
        ["reserveGraph", END]
    )
    .add_edge("reserveGraph", END)
    .add_edge("extendGraph", END)
    .add_edge("get_user_preferences", END)
    .compile()
)
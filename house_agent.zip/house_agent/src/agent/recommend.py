from langgraph.graph import StateGraph
from langgraph.constants import START, END

from src.node.recommend import call_get_schema, check_query, collect_user_info, generate_query, list_tables, get_schema_node, run_query_node
from src.state.recommend import recommendState
from src.common.context import context_schema

def summary_or_check(state: recommendState):
    lastMsg = state["messages"][-1]
    if len(lastMsg.tool_calls) > 0:
        return "check_query"
    return END
builder = (
    StateGraph(recommendState, context_schema=context_schema)
    .add_node(collect_user_info)
    .add_node(list_tables)
    .add_node(call_get_schema)
    .add_node("get_schema", get_schema_node)
    .add_node(generate_query)
    .add_node(check_query)
    .add_node("run_query", run_query_node)
    .add_edge(START, "collect_user_info")
    .add_edge("collect_user_info", "list_tables")
    .add_edge("list_tables", "call_get_schema")
    .add_edge("call_get_schema", "get_schema")
    .add_edge("get_schema", "generate_query")
    .add_conditional_edges(
        "generate_query",
        summary_or_check,
        [END, "check_query"]
    )
    .add_edge("check_query", "run_query")
    .add_edge("run_query", "generate_query")
)

recommendGraph = builder.compile(checkpointer=True)
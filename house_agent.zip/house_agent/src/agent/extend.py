from langgraph.graph import MessagesState, StateGraph
from langgraph.constants import START, END

from src.node.extend import extend

extendGraph = (
    StateGraph(MessagesState)
    .add_node(extend)
    .add_edge(START, "extend")
    .add_edge("extend", END)
    .compile()
)
import os
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit

from langchain.chat_models import init_chat_model

model = init_chat_model(
    model="deepseek-chat", 
    model_provider="openai", 
    base_url="https://api.deepseek.com/v1", 
    temperature=0
)

from dotenv import load_dotenv
load_dotenv()
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')
db_host = os.getenv('DB_HOST')
db_port = os.getenv('DB_PORT')
db_name = os.getenv('DB_NAME')
print(db_user)
print(db_password)
print(db_host)
print(db_port)
print(db_name)
db = SQLDatabase.from_uri(f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}")

# 获取数据库工具​
toolkit = SQLDatabaseToolkit(db=db, llm=model)
tools = toolkit.get_tools()
for tool in tools:
    print(tool.name)
# [
#     sql_db_query QuerySQLDatabaseTool(description="Input to this tool is a detailed and correct SQL query, output is a result from the database. If the query is not correct, an error message will be returned. If an error is returned, rewrite the query, check the query, and try again. If you encounter an issue with Unknown column 'xxxx' in 'field list', use sql_db_schema to query the correct table fields.", db=<langchain_community.utilities.sql_database.SQLDatabase object at 0x7f405afe84a0>), 
#     sql_db_schema InfoSQLDatabaseTool(description='Input to this tool is a comma-separated list of tables, output is the schema and sample rows for those tables. Be sure that the tables actually exist by calling sql_db_list_tables first! Example Input: table1, table2, table3', db=<langchain_community.utilities.sql_database.SQLDatabase object at 0x7f405afe84a0>), 
#     sql_db_list_tables ListSQLDatabaseTool(db=<langchain_community.utilities.sql_database.SQLDatabase object at 0x7f405afe84a0>), 
#     sql_db_query_checker QuerySQLCheckerTool(description='Use this tool to double check if your query is correct before executing it. Always use this tool before executing a query with sql_db_query!', db=<langchain_community.utilities.sql_database.SQLDatabase object at 0x7f405afe84a0>, llm=ChatOpenAI(profile={}, client=<openai.resources.chat.completions.completions.Completions object at 0x7f405b7692e0>, async_client=<openai.resources.chat.completions.completions.AsyncCompletions object at 0x7f405b2dce90>, root_client=<openai.OpenAI object at 0x7f408b2b3530>, root_async_client=<openai.AsyncOpenAI object at 0x7f405b76afc0>, model_name='deepseek-chat', temperature=0.0, model_kwargs={}, openai_api_key=SecretStr('**********'), openai_api_base='https://api.deepseek.com/v1'), llm_chain=LLMChain(verbose=False, prompt=PromptTemplate(input_variables=['dialect', 'query'], input_types={}, partial_variables={}, template='\n{query}\nDouble check the {dialect} query above for common mistakes, including:\n- Using NOT IN with NULL values\n- Using UNION when UNION ALL should have been used\n- Using BETWEEN for exclusive ranges\n- Data type mismatch in predicates\n- Properly quoting identifiers\n- Using the correct number of arguments for functions\n- Casting to the correct data type\n- Using the proper columns for joins\n\nIf there are any of the above mistakes, rewrite the query. If there are no mistakes, just reproduce the original query.\n\nOutput the final SQL query only.\n\nSQL Query: '), llm=ChatOpenAI(profile={}, client=<openai.resources.chat.completions.completions.Completions object at 0x7f405b7692e0>, async_client=<openai.resources.chat.completions.completions.AsyncCompletions object at 0x7f405b2dce90>, root_client=<openai.OpenAI object at 0x7f408b2b3530>, root_async_client=<openai.AsyncOpenAI object at 0x7f405b76afc0>, model_name='deepseek-chat', temperature=0.0, model_kwargs={}, openai_api_key=SecretStr('**********'), openai_api_base='https://api.deepseek.com/v1'), output_parser=StrOutputParser(), llm_kwargs={}))
# ]